
<body onload="if (location.search.length < 1){ document.getElementById('getloc').submit()}">
<?php $__env->startSection('content'); ?>
<body>
  
<?php if(Session('message')): ?>
<div class="toast fade show" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="3000" >
      <div class="toast-header">
        <strong class="me-auto"><?php echo e(Session::get('alert-class')); ?></strong>
        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
      <div class="toast-body">
        <strong> <?php echo e(Session('message')); ?> </strong>
      </div>
</div>
  <?php endif; ?>

    <br/>

  <div class="alert container-md alert-dismissible">
     </div>


<a href="/create" ><button class="btn btn-primary" style="float: right">ADD NEW COMPANY</button></a>
<br>
<form action="/search" method="GET">
  <input type="text" name="name" id="name" placeholder="Search by name">
  <input type="email" name="email" id="email" placeholder="Search by email">
  <input type="text" name="phone" id="phone" placeholder="Search by phone">
  <input type="date" name="date" id="date" placeholder="Search by date"> 
  <input type="submit">
</form>


  <table class="table">

    
<thead>
  <tr>
    <th scope="col">ID</th>
    <th scope="col">Company Name</th>
    <th scope="col">Email</th>
    <th scope="col">Address</th>
    <th scope="col">Phone Number</th>
    <th scope="col">Distance</th>
    <th scope="col">Date Registered</th>
    <th scope="col">Status</th>
    <th scope="col-3">Action</th>
 
  </tr>
</thead>

<tbody>
    <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    if($company->status == '0'){
      $company->status = 'Not Verified';

    }
    else if($company->status == '1' ){
      $company->status = 'Verified';
    }else {
      $company->status = 'Undefined';
    }
    ?>
  <tr>
    <td><?php echo e($company->id); ?></td>
    <td><?php echo e($company->name); ?></td>
    <td><?php echo e($company->email); ?></td>
    <td><?php echo e($company->address); ?></td>
    <td><?php echo e($company->phone); ?></td>
    <td><a href="http://maps.google.com/?q=<?php echo e($company->latitude); ?> + ',' + <?php echo e($company->longitude); ?>"></a><?php echo e(number_format($company->distance)); ?></span>K.M</td>
    <td><?php echo e($company->created_at); ?></td>
    <td><?php echo e($company->status); ?></td>
    <td>
        
      
    <a class="btn btn-success edit" href="/company/edit/<?php echo e($company->id); ?>"><i class="fa-solid fa-pencil"></i></a>
    <a class="btn btn-primary" href="./status<%=data[i].id%>"><i class="fa-solid fa-cog"></i></a>
    
    <a class="btn btn-danger" href="/company/<?php echo e($company->id); ?>"  onclick="return confirm('Are you sure you want to delete the company')"><i class="fa-solid fa-trash"></i></a>
  </form>
   </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  <!-- <% }
           
   }else{ %>
       <tr>
          <td colspan="3">No Information</td>
       </tr>
    <% } %>     -->
  
</tbody>
</table>
  </div>
</body>
<?php $__env->stopSection(); ?>
<!-- <script>

  let userLat = document.getElementsByClassName("user-lat");
  let userLong = document.getElementsByClassName("user-long");
  let km = document.getElementsByClassName("km");

  const lng = sessionStorage.getItem("lng");
  const lat = sessionStorage.getItem("lat");
  function addLatAndLong(latitude1, longitude1, latitude2, longitude2) {
          let R = 6371; // km
          let dLat = toRad(latitude2 - latitude1);
          let dLon = toRad(longitude2 - longitude1);
          latitude1 = toRad(latitude1);
          latitude2 = toRad(latitude2);

          let a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(latitude1) * Math.cos(latitude2);
          let c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
          let result = R * c;
          

          function toRad(Value) {
            return Value * Math.PI / 180;
          }

          let i = 0;
          return parseFloat(result).toFixed(2);

    }

    function displayKm() {
      for (let i = 0; i < km.length; i++) {
        km[i].innerHTML = addLatAndLong(lat, lng, userLat[i].innerHTML, userLong[i].innerHTML);
      }
    }

    displayKm();
    
</script> -->
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\go2work\resources\views/company/index.blade.php ENDPATH**/ ?>