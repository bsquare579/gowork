

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card col-md-6">
      <div class="card-body">
        <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
  <?php endif; ?>
        
    <script src="https://maps.googleapis.com/maps/api/js?libraries=places&callback=initAutocomplete&language=eng&output=json&key=AIzaSyDuAySsU56eFj3o_IbeY18jo2fZNLzJ9CY" async defer></script>


        <h2>Add Bussiness</h2>

        <form action="/addBussiness" method="POST">
          <div class="form-group">
            <label for="Name">Name</label>
            <input type="text" class="form-control col-lg-9" id="name" placeholder="Enter Bussiness Name" name="name" required>
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control col-lg-9" id="email" placeholder="Enter Your Email" name="email" required>
          </div>
          <div class="form-group">
            <label for="address">Address</label>
            <input type="address" class="form-control col-lg-9" id="address" spellcheck="false" autocomplete="off" placeholder="Enter Bussiness Address" name="address" required>
          </div>
          <!-- <div class="form-group">
            <label for="latitude">Latitude</label> -->
            <input type="hidden" class="form-control col-lg-9" id="lat" placeholder="Get Latitude" name="lat" readonly required>
          <!-- </div>
          <div class="form-group">
            <label for="Longitude">Longitude</label> -->
            <input type="hidden" class="form-control col-lg-9" id="lng" placeholder="Get Longitude" name="lng" readonly required>
          <!-- </div> -->
          
          <div class="form-group">
            <label for="phone">Phone Number</label>
            <input type="text"  maxlength="11" class="form-control col-lg-9" id="phone" placeholder="Enter Your Phone No" name="phone" required>
          </div>

          <br/>
          <button type="submit" class="btn btn-primary">Submit</button>&ensp;<a href="/list"><button type="button" class="btn btn-primary"> View Businesses</button></a>
        </form>
  </div>
</div>
  <?php $__env->stopSection(); ?>
<script>
  function initAutocomplete() {


var address = document.getElementById('address');
var options = {
componentRestrictions: {country: ['ng']}
};

var autocomplete = new google.maps.places.Autocomplete(address, options);

autocomplete.addListener('place_changed', function() {
  var place = autocomplete.getPlace();
  var lat = place.geometry.location.lat();
  var lng = place.geometry.location.lng();
  document.getElementById('lat').value = lat;
  document.getElementById('lng').value = lng;
  
});

}

</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\go2work\resources\views/company/addCompany.blade.php ENDPATH**/ ?>