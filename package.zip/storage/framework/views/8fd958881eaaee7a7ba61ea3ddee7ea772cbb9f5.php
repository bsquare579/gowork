
        <?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card col-md-6">
      <div class="card-body">
       
      <?php if(Session('message')): ?>
<div class="toast fade show" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="3000" >
      <div class="toast-header">
        <strong class="me-auto"><?php echo e(Session::get('alert-class')); ?></strong>
        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
      <div class="toast-body">
        <strong> <?php echo e(Session('message')); ?> </strong>
      </div>
</div>
  <?php endif; ?>

    <script src="https://maps.googleapis.com/maps/api/js?libraries=places&callback=initAutocomplete&language=eng&output=json&key=<?php echo e(env('API_KEY')); ?>&callback=initAutocomplete" async defer></script>


        <h2>Edit Bussiness</h2>
        <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <form action="<?php echo e(url('/company', $row->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>

          <div class="form-group">
            <label for="Name">Name</label>
            <input type="text" class="form-control col-lg-9" id="name" placeholder="Enter Bussiness Name" name="name" value="<?php echo e($row->name); ?>" required>
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control col-lg-9" id="email" placeholder="Enter Your Email" name="email" value="<?php echo e($row->email); ?>" required>
          </div>
          <div class="form-group">
            <label for="address">Address</label>
            <input type="text" class="form-control col-lg-9" id="address" spellcheck="false" autocomplete="off" placeholder="Enter Bussiness Address" name="address" value="<?php echo e($row->address); ?>" required>
          </div>
          <!-- <div class="form-group">
            <label for="latitude">Latitude</label> -->
            <input type="hidden" class="form-control col-lg-9" id="latitude" placeholder="Get Latitude" name="latitude" value="<?php echo e($row->latitude); ?>" readonly required>
          <!-- </div>
          <div class="form-group">
            <label for="Longitude">Longitude</label> -->
            <input type="hidden" class="form-control col-lg-9" id="longitude" placeholder="Get Longitude" name="longitude" value="<?php echo e($row->longitude); ?>" readonly required>
          <!-- </div> -->
          
          <div class="form-group">
            <label for="phone">Phone Number</label>
            <input type="tel"  maxlength="11" minlength="11" class="form-control col-lg-9" id="phone" placeholder="Enter Your Phone No" name="phone" value="<?php echo e($row->phone); ?>" required>
          </div>

          <br/>
          <button type="submit" class="btn btn-primary">Submit</button>&ensp;<a href="/company/create"><button type="button" class="btn btn-primary"> Register New Bussiness</button></a>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<script>
  function initAutocomplete() {


var address = document.getElementById('address');
var options = {
componentRestrictions: {country: ['ng']}
};

var autocomplete = new google.maps.places.Autocomplete(address, options);

autocomplete.addListener('place_changed', function() {
  var place = autocomplete.getPlace();
  var latitude = place.geometry.location.lat();
  var longitude = place.geometry.location.lng();;
  document.getElementById('latitude').value = latitude;
  document.getElementById('longitude').value = longitude;
  
});

}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\go2work\resources\views/company/edit.blade.php ENDPATH**/ ?>